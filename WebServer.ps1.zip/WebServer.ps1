﻿Configuration ProvisionVM
{
  param ($MachineName)
  Import-DscResource -ModuleName PSDesiredStateConfiguration, xWebAdministration
  

  Node $MachineName
    {
          LocalConfigurationManager {
            RebootNodeIfNeeded = $true
            ActionAfterReboot = 'ContinueConfiguration'
            ConfigurationMode = 'ApplyOnly'
        }
            Script InstallChocolatey
        {
            GetScript = { @{} }
            SetScript =
            {
                Install-PackageProvider chocolatey -Force
            }
            TestScript =
            {
                $installed = get-packageprovider chocolatey
                $installed.Name -contains 'Chocolatey'
            }			
        }

              WindowsFeature NET-Framework-Core
            {
              Ensure = 'Present'
              Name = 'NET-Framework-Core'
            }
              WindowsFeature Web-Server
            {
              Ensure = 'Present'
              Name = 'Web-Server'
            }

             WindowsFeature Web-Asp-Net45
            {
              Ensure = 'Present'
              Name = 'Web-Asp-Net45'
            }

             WindowsFeature Web-Mgmt-Console
            {
              Ensure = 'Present'
              Name = 'Web-Mgmt-Console'
            }

        Script ChangeDVDDriveLetter {
 
            Getscript = 
            {
                $DVDDrivePath = 'E:\'
                return @{
                    Result     = Test-Path $DVDDrivePath
                    GetScript  = $GetScript
                    TestScript = $TestScript
                    SetScript  = $SetScript
                }
            }
            SetScript = {
                (Get-CimInstance -Class Win32_CDROMDrive).drive | ForEach-Object -Process {
                    $DVDDrive = mountvol.exe $_ /l
                    mountvol.exe $_ /d
                    $DVDDrive = $DVDDrive.Trim()
                    mountvol.exe z: $DVDDrive
                }
            }
            TestScript = {
                $Path = 'Z:\'
                if (Test-Path $Path)
                {
                    Write-Verbose -Message "The drive with the letter $Path exists, no action required"
                    $True
                }
                Else
                {
                    Write-Verbose -Message "The drive with the letter $Path is missing. Changing the DVD Drive letter"
                    $False
                }
            }
        }

        File indexFile
        {
                DestinationPath =         'c:\inetpub\wwwroot\Demo\index.html'
                Ensure = 'Present'
                Contents = "<h1>Hello World! $env:computername here</h1>"
        }

            xWebsite DefaultWebSite
            {
            Ensure = 'Absent'
            Name = 'Default Web Site'

            }

        xWebAppPool demoAppPool
        {
        DependsOn = '[WindowsFeature]Web-Server'
        Name = 'DemoTraining'
        Ensure = 'Present'
        autoStart = $true
        
        }

        xWebsite demoWebsite
        {
        DependsOn = '[xWebAppPool]demoAppPool'
        Name = 'Demo Web Application'
        Ensure = 'Present'
        ApplicationPool = 'demoAppPool'
        PhysicalPath =         'C:\inetpub\wwwroot\Demo'
        BindingInfo = @(
                        @(MSFT_xWebBindingInformation   
                            {  
                                Protocol              = 'HTTP'
                                Port                  =  80 
                                
                            }
                        );
                       )
        }

    }
} 